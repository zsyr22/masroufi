"use client";

import { useActionState, useMemo, useState } from "react";
import Link from "next/link";
import {
  Globe2,
  Loader2,
  MapPin,
  ReceiptText,
  ShoppingBasket,
  Sparkles,
  Store as StoreIcon,
} from "lucide-react";

import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { AccountWithBalance } from "@/features/accounts/types/account";
import { createPurchase, updatePurchase, type PurchaseActionState } from "@/features/purchases/actions/purchase-actions";
import { BulkPasteImporter } from "@/features/purchases/components/bulk-paste-importer";
import { createEmptyPurchaseItem, PurchaseItemsEditor } from "@/features/purchases/components/purchase-items-editor";
import { PurchaseTotalsCard } from "@/features/purchases/components/purchase-totals-card";
import type { ProductSuggestion, PurchaseFormInitialData, PurchaseItemInput, Store } from "@/features/purchases/types/purchase";
import { calculatePurchaseTotals } from "@/features/purchases/utils/purchase-calculations";
import type { Category } from "@/features/transactions/types/transaction";
import { cn } from "@/lib/utils";

const initialState: PurchaseActionState = {};

function today() {
  const date = new Date();
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 10);
}

type Props = {
  accounts: AccountWithBalance[];
  categories: Category[];
  stores: Store[];
  products: ProductSuggestion[];
  purchaseId?: string;
  initialData?: PurchaseFormInitialData;
};

export function PurchaseForm({ accounts, categories, stores, products, purchaseId, initialData }: Props) {
  const expenseCategories = categories.filter((category) => category.transaction_type === "expense");
  const [accountId, setAccountId] = useState(initialData?.accountId ?? accounts[0]?.id ?? "");
  const [categoryId, setCategoryId] = useState(
    initialData?.categoryId
    ?? expenseCategories.find((category) => /grocer|food|shopping/i.test(category.name))?.id
    ?? expenseCategories[0]?.id
    ?? "",
  );
  const [storeId, setStoreId] = useState(initialData?.storeId ?? stores[0]?.id ?? "");
  const selectedStore = stores.find((store) => store.id === storeId);
  const [channel, setChannel] = useState<"online" | "physical">(
    initialData?.channel ?? selectedStore?.default_channel ?? "online",
  );
  const [entryMode, setEntryMode] = useState<"quick" | "itemized">(
    initialData && !initialData.items.length ? "quick" : "itemized"
  );
  const [items, setItems] = useState<PurchaseItemInput[]>(
    initialData?.items?.length ? initialData.items : [createEmptyPurchaseItem()],
  );
  const [tax, setTax] = useState(initialData?.tax ?? 0);
  const [discount, setDiscount] = useState(initialData?.discount ?? 0);
  const [deliveryFee, setDeliveryFee] = useState(initialData?.deliveryFee ?? 0);
  const [receiptTotal, setReceiptTotal] = useState(initialData?.total ?? 0);

  const formAction = purchaseId ? updatePurchase.bind(null, purchaseId) : createPurchase;
  const [state, action, pending] = useActionState(formAction, initialState);
  const account = accounts.find((current) => current.id === accountId);
  const category = expenseCategories.find((current) => current.id === categoryId);
  const totals = useMemo(
    () => calculatePurchaseTotals(items, tax, discount, channel === "online" ? deliveryFee : 0),
    [items, tax, discount, deliveryFee, channel],
  );

  function changeStore(value: string) {
    setStoreId(value);
    const store = stores.find((current) => current.id === value);
    if (!store) return;
    setChannel(store.default_channel);
    if (store.default_channel === "physical") setDeliveryFee(0);
  }

  function importItems(importedItems: PurchaseItemInput[]) {
    setEntryMode("itemized");
    const onlyBlankItem = items.length === 1
      && !items[0].name.trim()
      && items[0].unitPrice === 0;
    setItems(onlyBlankItem ? importedItems : [...items, ...importedItems]);
  }

  function importTotals(values: { tax?: number; discount?: number; deliveryFee?: number; total?: number }) {
    if (values.tax !== undefined) setTax(values.tax);
    if (values.discount !== undefined) setDiscount(values.discount);
    if (values.deliveryFee !== undefined) setDeliveryFee(values.deliveryFee);
    if (values.total !== undefined) setReceiptTotal(values.total);
  }

  return (
    <form action={action} className="space-y-6" aria-busy={pending}>
      <input type="hidden" name="accountId" value={accountId} />
      <input type="hidden" name="categoryId" value={categoryId} />
      <input type="hidden" name="storeId" value={storeId} />
      <input type="hidden" name="channel" value={channel} />
      <input type="hidden" name="items" value={JSON.stringify(items)} />

      <Card className="border-amber-500/20 bg-gradient-to-br from-amber-500/10 via-card to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="flex size-9 items-center justify-center rounded-xl bg-amber-500/15 text-amber-600">
              <ShoppingBasket className="size-4" />
            </span>
            Receipt details
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-5 sm:grid-cols-2">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Store</Label>
              <Link href="/stores" className="text-xs font-medium text-amber-600 hover:underline">Manage stores</Link>
            </div>
            <Select value={storeId} onValueChange={(value) => value && changeStore(value)}>
              <SelectTrigger className="h-9 w-full"><span>{selectedStore?.name ?? "Select store"}</span><SelectValue className="sr-only" /></SelectTrigger>
              <SelectContent>{stores.map((store) => <SelectItem key={store.id} value={store.id}>{store.name}</SelectItem>)}</SelectContent>
            </Select>
            {!stores.length ? <p className="text-xs text-destructive">Add a store first from Stores.</p> : null}
          </div>

          <div className="space-y-2">
            <Label>Shopping method</Label>
            <div className="grid grid-cols-2 gap-2 rounded-xl bg-background/60 p-1">
              <button type="button" onClick={() => setChannel("online")} className={cn("flex h-9 items-center justify-center gap-2 rounded-lg text-sm font-medium transition", channel === "online" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground")}>
                <Globe2 className="size-4" />Online
              </button>
              <button type="button" onClick={() => { setChannel("physical"); setDeliveryFee(0); }} className={cn("flex h-9 items-center justify-center gap-2 rounded-lg text-sm font-medium transition", channel === "physical" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground")}>
                <MapPin className="size-4" />Physical
              </button>
            </div>
          </div>

          {channel === "physical" ? (
            <div className="space-y-2">
              <Label htmlFor="branchName">Branch <span className="text-muted-foreground">optional</span></Label>
              <Input id="branchName" name="branchName" placeholder="Dubai Festival City" defaultValue={initialData?.branchName ?? ""} />
            </div>
          ) : (
            <div className="space-y-2">
              <Label>Online store</Label>
              <div className="flex h-9 items-center gap-2 rounded-lg border border-input bg-background/40 px-3 text-sm text-muted-foreground">
                <StoreIcon className="size-4" />{selectedStore?.website ?? selectedStore?.name ?? "Select a store"}
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label>Paid from</Label>
            <Select value={accountId} onValueChange={(value) => value && setAccountId(value)}>
              <SelectTrigger className="h-9 w-full"><span>{account ? `${account.name} · ${account.currency}` : "Select account"}</span><SelectValue className="sr-only" /></SelectTrigger>
              <SelectContent>{accounts.map((current) => <SelectItem key={current.id} value={current.id}>{current.name} · {current.currency}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Main category</Label>
            <Select value={categoryId} onValueChange={(value) => value && setCategoryId(value)}>
              <SelectTrigger className="h-9 w-full"><span>{category?.name ?? "Select category"}</span><SelectValue className="sr-only" /></SelectTrigger>
              <SelectContent>{expenseCategories.map((current) => <SelectItem key={current.id} value={current.id}>{current.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="purchaseDate">Date</Label>
            <Input id="purchaseDate" name="purchaseDate" type="date" defaultValue={initialData?.purchaseDate ?? today()} required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" name="notes" rows={2} placeholder="Weekly groceries..." defaultValue={initialData?.notes ?? ""} />
          </div>
        </CardContent>
      </Card>

      <Card className="border-amber-500/15 bg-gradient-to-br from-amber-500/5 via-card to-transparent">
        <CardHeader className="gap-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle className="flex items-center gap-2"><ReceiptText className="size-4 text-amber-500" />Purchase entry</CardTitle>
              <p className="mt-1 text-xs text-muted-foreground">Save only the receipt total now, or record every product.</p>
            </div>
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-background/60 p-1">
              <button
                type="button"
                onClick={() => { setEntryMode("quick"); setItems([]); setTax(0); setDiscount(0); setDeliveryFee(0); }}
                className={cn("rounded-lg px-4 py-2 text-sm font-medium transition", entryMode === "quick" ? "bg-card shadow-sm" : "text-muted-foreground")}
              >
                Total only
              </button>
              <button
                type="button"
                onClick={() => { setEntryMode("itemized"); if (!items.length) setItems([createEmptyPurchaseItem()]); }}
                className={cn("rounded-lg px-4 py-2 text-sm font-medium transition", entryMode === "itemized" ? "bg-card shadow-sm" : "text-muted-foreground")}
              >
                Itemized
              </button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {entryMode === "quick" ? (
            <div className="mx-auto max-w-md space-y-3 rounded-xl border border-amber-500/15 bg-background/60 p-5">
              <Label htmlFor="quickReceiptTotal">Receipt total</Label>

              <div className="relative">
                <Input
                  id="quickReceiptTotal"
                  name="total"
                  type="number"
                  min="0.01"
                  step="0.01"
                  value={receiptTotal}
                  onChange={(event) =>
                    setReceiptTotal(Number(event.target.value))
                  }
                  className="h-12 pr-16 text-lg font-semibold"
                  placeholder="0.00"
                  required
                />

                <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-sm text-muted-foreground">
                  {account?.currency ?? "AED"}
                </span>
              </div>

              <input type="hidden" name="tax" value="0" />
              <input type="hidden" name="discount" value="0" />
              <input type="hidden" name="deliveryFee" value="0" />

              <p className="text-xs text-muted-foreground">
                You can open this purchase later, switch to Itemized, and add all
                products.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex justify-end">
                <BulkPasteImporter
                  products={products}
                  currency={account?.currency ?? "AED"}
                  onImportItems={importItems}
                  onImportTotals={importTotals}
                />
              </div>

              <PurchaseItemsEditor
                items={items}
                products={products}
                currency={account?.currency ?? "AED"}
                onChange={setItems}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {entryMode === "itemized" ? (
        <PurchaseTotalsCard
          subtotal={totals.subtotal}
          tax={tax}
          discount={discount}
          deliveryFee={deliveryFee}
          showDeliveryFee={channel === "online"}
          receiptTotal={receiptTotal}
          currency={account?.currency ?? "AED"}
          calculatedTotal={totals.total}
          onTaxChange={setTax}
          onDiscountChange={setDiscount}
          onDeliveryFeeChange={setDeliveryFee}
          onReceiptTotalChange={setReceiptTotal}
        />
      ) : null}

      {state.message ? <p className="rounded-xl bg-destructive/10 px-4 py-3 text-sm text-destructive">{state.message}</p> : null}

      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Link href={purchaseId ? `/purchases/${purchaseId}` : "/purchases"} className={cn(buttonVariants({ variant: "outline" }), pending && "pointer-events-none opacity-50")}>Cancel</Link>
        <Button
          type="submit"
          disabled={
            pending
            || !storeId
            || receiptTotal <= 0
            || (entryMode === "itemized" && (
              Math.abs(totals.total - receiptTotal) > 0.02
              || !items.length
              || items.some((item) => !item.name.trim())
            ))
          }
        >
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
          {pending ? (purchaseId ? "Updating purchase..." : "Saving receipt...") : (purchaseId ? "Update purchase" : "Save purchase")}
        </Button>
      </div>
    </form>
  );
}
