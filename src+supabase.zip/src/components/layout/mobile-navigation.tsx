"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  ArrowLeftRight,
  ChartNoAxesCombined,
  Landmark,
  LayoutDashboard,
  Menu,
  Repeat2,
  Settings,
  Tags,
  Users,
  WalletCards,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { LogoutButton } from "@/features/auth/components/logout-button";
import { cn } from "@/lib/utils";

const navigationItems = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Accounts", href: "/accounts", icon: WalletCards },
  { label: "Transactions", href: "/transactions", icon: ArrowLeftRight },
  { label: "Transfers", href: "/transfers", icon: Landmark },
  { label: "Categories", href: "/categories", icon: Tags },
  { label: "People", href: "/people", icon: Users },
  { label: "Subscriptions", href: "/subscriptions", icon: Repeat2 },
  { label: "Reports", href: "/reports", icon: ChartNoAxesCombined },
  { label: "Settings", href: "/settings", icon: Settings },
];

export function MobileNavigation() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b bg-background/95 px-5 backdrop-blur md:hidden">
      <Link href="/dashboard" className="text-lg font-semibold tracking-tight">
        Masroufi
      </Link>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger render={<Button variant="outline" size="icon" aria-label="Open navigation" />}>
          <Menu className="size-5" />
        </DialogTrigger>

        <DialogContent className="top-0 left-auto right-0 h-dvh max-w-[20rem] translate-x-0 translate-y-0 content-start rounded-none p-5 sm:max-w-[22rem]">
          <DialogHeader className="pr-10">
            <DialogTitle>Masroufi</DialogTitle>
            <DialogDescription>Navigate through your finance workspace.</DialogDescription>
          </DialogHeader>

          <nav className="mt-4 flex flex-col gap-1">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-accent text-accent-foreground"
                      : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="mt-auto border-t pt-4">
            <LogoutButton />
          </div>
        </DialogContent>
      </Dialog>
    </header>
  );
}
